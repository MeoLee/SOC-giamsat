# Bộ triển khai SOC AI — candidate1

Đây là bản dựng để kiểm thử, CHƯA được chạy end-to-end trên Docker Desktop của người dùng. Không coi YAML parse thành công là nghiệm thu deployment. Bộ model đã kiểm chứng vẫn cần chép từ máy người dùng. Không có private key hoặc VT API key cá nhân. Wazuh4.14.7 dùng cấu hình official tag v4.14.7; các mật khẩu mặc định lab trong cấu hình official KHÔNG phải mật khẩu cá nhân. Chỉ bind các cổng Wazuh vào127.0.0.1.

## Cấu trúc
SOC-AI-Lab: runtime Compose/AI/model/config. Model-Training: nguồn train/UI riêng ngoài Compose. Tai-Lieu: tài liệu ngoài Compose. Archive không chứa dataset, .venv, cache, log cũ, checkpoint hoặc DockerData. Model cuối đặt trong model/mlp04-quality và mount read-only. Session ghi ra runtime/sessions.

## Chuẩn bị trên máy hiện tại
Giải nén vào E:\SOC-Lab\Bai-Nop (giữ nguyên thư mục model đã chép). Chạy `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Prepare.ps1` tại SOC-AI-Lab. Lệnh chỉ chuẩn bị file và validate Compose, không start/xóa container.

Các container lab cũ dùng trùng tên và dải172.20.0.0/24. KHÔNG chạy `up` trên cùng Docker daemon khi container cũ còn giữ tên/network. Để dựng thử an toàn, dùng máy/Docker context sạch. Không xóa container/volume cũ chỉ để vượt lỗi name conflict. Không chép E:\DockerData vào bộ nộp. Vị trí DockerData do Docker Desktop của từng máy quản lý.

## Dựng trên máy sạch
1. Docker Desktop Linux containers, Compose v2, Internet và tài nguyên đủ cho Wazuh + AI (khuyến nghị Docker RAM>=8GB, dung lượng trống>=30GB; thực tế phụ thuộc image). Đặt vm.max_map_count>=262144 cho Linux VM theo hướng dẫn Wazuh.
2. Chạy Prepare.ps1 và kiểm tra sáu file model.
3. `docker compose -f generate-indexer-certs.yml run --rm generator` tạo certificate MỚI. Không lấy certificate/key cá nhân từ máy cũ.
4. `docker compose build` tải base images và dependencies. Ubuntu26.04/packages apt và kali-rolling có thể thay đổi theo thời gian; chưa pin toàn bộ transitive dependencies/digest. Đây chưa phải reproducible offline build. DVWA được installer tải về từ upstream, cần kiểm thử lại phiên bản thực tế.
5. `docker compose up -d wazuh.indexer wazuh.manager wazuh.dashboard ubuntu-endpoint kali-attacker`
6. `docker compose --profile setup run --rm bootstrap` cài DVWA/rules/observer và chạy Doctor. Chỉ tiếp tục nếu exit0 và BOOTSTRAP_VERIFIED.
7. Import dashboards/soc-ai-attack-chain-unified.ndjson vào Wazuh Saved objects với Overwrite, mở https://localhost. Chưa tự động import trong candidate1.
8. `docker compose --profile ai run --rm ai` bật monitor foreground. Ctrl+C kết thúc, đợi session đóng. Mở Kali Bash khi cần từ terminal riêng; không nhập session ID. Tài liệu này không cung cấp payload hoặc lệnh tấn công.

## Giới hạn phải biết
AI controller dùng Docker CLI + bind Docker socket để tương thích collector/installers hiện có. Điều này cấp quyền quản lý Docker daemon cho controller; socket:ro không giới hạn Docker API. Chỉ chạy controller nguồn tin cậy của lab, không dùng kiến trúc này làm sandbox đa người dùng. Chuyển sang shared-volume collector không có socket là công việc tách riêng, chưa thực hiện trong candidate1.

Endpoint entrypoint khởi động agent, rsyslog, SSH và Suricata; web/observer được bootstrap cài. Sau restart endpoint phải chạy bootstrap lại và Doctor, không giả định observer luôn sống. Restart có thể mất heartbeat/rules hotreload; cần kiểm tra thực tế.

VT là tùy chọn, chưa bật tự động: cấu hình key riêng sau khi nghiệm thu core; không dùng lại key cá nhân trong bundle. Chưa xuất index lịch sử, DB DVWA cũ, account registry Wazuh cũ hoặc lịch sử dashboard. Đây là dựng môi trường sạch, không phải backup chính xác toàn bộ lab cũ.

## Điều kiện nghiệm thu
Model golden verify pass; agent active; Suricata SID collection thực sự thấy packet; web/observer Doctor pass; smoke event vào Wazuh; dashboard nhận stage/summary đúng phiên; correlation6bước không dừng do6000bytes; idle95s tách episode; Ctrl+C lưu session; restart test; không lộ VT key. Các mục này chưa được candidate1 thực hiện end-to-end.
