[CmdletBinding()]
param([string]$ModelSource='E:\SOC-Lab\AI\runs\mlp04-quality-20261019-232507')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$dst=Join-Path $root 'model\mlp04-quality'
New-Item -ItemType Directory -Path $dst -Force | Out-Null
foreach($n in @('features.json','model.json','model-weights.npz','preprocessor.json','golden.json','golden-predictions.json')) {
 $to=Join-Path $dst $n
 if(-not (Test-Path -LiteralPath $to)) { Copy-Item -LiteralPath (Join-Path $ModelSource $n) -Destination $to }
 if(-not (Test-Path -LiteralPath $to -PathType Leaf)) {throw "Missing model file $n"}
}
if(-not (Test-Path (Join-Path $root '.env'))) {Copy-Item (Join-Path $root '.env.example') (Join-Path $root '.env')}
Push-Location $root
try {
 & docker compose config --quiet
 if($LASTEXITCODE -ne 0){throw 'Compose validation failed'}
 Write-Host 'PREPARED. No containers started; existing DockerData and volumes unchanged.'
} finally {Pop-Location}
