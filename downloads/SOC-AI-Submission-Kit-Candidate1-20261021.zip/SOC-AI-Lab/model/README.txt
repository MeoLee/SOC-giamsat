Copy the verified six-file bundle into mlp04-quality/. Model files are not embedded in this archive.
