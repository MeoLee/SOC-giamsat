"""Deployment controller; uses the host Docker daemon for the existing collector."""
import subprocess,sys,time,json
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/app')
def run(*args):subprocess.run(list(args),cwd=ROOT,check=True)
def bootstrap():
    for name in ('ubuntu-endpoint','kali-attacker','single-node-wazuh.manager-1'):
        for _ in range(150):
            r=subprocess.run(['docker','exec',name,'true'],capture_output=True)
            if r.returncode==0:break
            time.sleep(2)
        else:raise RuntimeError('Container not ready: '+name)
    # Wait for agent enrollment and analysisd, not only a running container.
    for _ in range(150):
        r=subprocess.run(['docker','exec','ubuntu-endpoint','sh','-c','test -s /var/ossec/etc/client.keys && /var/ossec/bin/wazuh-control status | grep -q "wazuh-agentd is running"'],capture_output=True)
        if r.returncode==0:break
        time.sleep(2)
    else:raise RuntimeError('Agent enrollment not ready')
    run('python','setup_web_lab.py')
    run('python','configure_web_live.py')
    run('python','setup_recon.py','--container','ubuntu-endpoint')
    run('python','setup_suricata_web.py','--container','ubuntu-endpoint')
    run('python','setup_scenario_fim.py','--sensor','ubuntu-endpoint')
    run('python','setup_scenario_rules.py','--manager','single-node-wazuh.manager-1')
    run('python','setup_process_observer.py','--sensor','ubuntu-endpoint','--username','soctest','--watch-artifacts')
    run('python','setup_attack_chains.py','--ssh-extended','--http-flood','--syn-flood')
    run('python','setup_wazuh.py','--manager','single-node-wazuh.manager-1')
    run('python','lab_doctor.py','--config','live-config.json','--model','/model','--runtime','--bridge')
    print('BOOTSTRAP_VERIFIED: import dashboards/soc-ai-attack-chain-unified.ndjson in Saved objects; configure VT separately if needed.',flush=True)
def monitor():
    run('python','lab_doctor.py','--config','live-config.json','--model','/model','--runtime','--bridge')
    dest='/sessions/monitor-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    run('python','-u','lab_live.py','--model','/model','--config','live-config.json','--output-dir',dest,'--publish-wazuh','--publish-observations','--summary-seconds','1','--interval','1','--grace','90','--heartbeat-seconds','10')
if __name__=='__main__':
    {'bootstrap':bootstrap,'monitor':monitor}[sys.argv[1]]()
