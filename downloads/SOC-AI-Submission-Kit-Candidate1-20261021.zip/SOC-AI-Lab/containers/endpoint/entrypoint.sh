#!/bin/bash
set -Eeuo pipefail
mkdir -p /run/sshd /var/log/suricata /var/log/soc-lab
ssh-keygen -A
printf 'soctest:%s\n' "${LAB_SSH_PASSWORD:?LAB_SSH_PASSWORD is required}" | chpasswd
/usr/sbin/rsyslogd -n -i /run/soc-lab-rsyslog.pid &
rpid=$!
cleanup() { trap - EXIT TERM INT; /var/ossec/bin/wazuh-control stop || true; apache2ctl -k stop || true; if test -n "${spid:-}"; then kill "$spid" 2>/dev/null || true; fi; kill "$rpid" 2>/dev/null || true; }
trap cleanup EXIT
trap 'exit 0' TERM INT
if ! test -s /var/ossec/etc/client.keys; then
  ready=no
  for i in $(seq 1 120); do
    if /var/ossec/bin/agent-auth -m 172.20.0.2 -p 1515 -A ubuntu-endpoint; then ready=yes; break; fi
    sleep 2
  done
  test "$ready" = yes || { echo 'Wazuh enrollment failed' >&2; exit 1; }
fi
/var/ossec/bin/wazuh-control start
/usr/sbin/sshd -D -e &
spid=$!
suricata -D -i eth0 -S /etc/suricata/rules/soc-lab.rules -l /var/log/suricata --pidfile /run/soc-lab-suricata.pid --set unix-command.enabled=yes
if test -x /usr/local/sbin/start-soc-web.sh; then /usr/local/sbin/start-soc-web.sh; fi
if test -f /usr/local/lib/soc-lab/process_observer.py; then python3 /usr/local/lib/soc-lab/process_observer.py --watch-artifacts & fi
wait -n "$rpid" "$spid"
