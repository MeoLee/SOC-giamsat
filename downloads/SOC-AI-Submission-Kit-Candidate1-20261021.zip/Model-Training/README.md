# Model Training (outside Compose)
Source includes soc_ai/train.py, prepare.py, dashboard.py, web/dashboard.html and shared modules/tests.
Create a separate Python3.12 environment. Install torch2.11.0 from the CPU wheel index and requirements-tested.txt. Start the UI with `python -m soc_ai dashboard --help` to see supported arguments. Datasets and training runs are not included. Copy the evaluated model bundle into SOC-AI-Lab/model/mlp04-quality only after verification. The demo never retrains automatically.
