"""Enable bounded campaign correlation, preserving the existing live config."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import shutil
from soc_ai.common import read_json, write_json
from live_config import load_config
from lab_campaign import DEFAULTS


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path(__file__).with_name('live-config.json'))
    parser.add_argument('--http-flood',action='store_true',help='Enable dedicated Apache HTTP-pressure/degradation alerts; requires 0.4.12 Wazuh bridge rules')
    parser.add_argument('--syn-flood',action='store_true',help='Enable unique SYN connection pressure alerts (119219)')
    parser.add_argument('--ssh-contact',action='store_true',help='Enable early neutral SSH contact candidates; requires Wazuh rule119221')
    parser.add_argument('--ssh-extended',action='store_true',help='Enable subthreshold auth, artifact and detached shell correlation')
    parser.add_argument('--failure-threshold',type=int,help='Explicit local password-failure policy; does not change model thresholds')
    a=parser.parse_args();load_config(a.config)
    config=read_json(a.config)
    candidate={**config,'correlation':{**DEFAULTS,**config.get('correlation',{}),'attack_chain_enabled':True}}
    if a.http_flood:
        if not any(s['kind']=='web' for s in load_config(a.config)['sources']):
            parser.error('HTTP flood detection requires an Apache TSV web source in live-config.json')
        candidate['correlation']['http_load_alerts_enabled']=True
    if a.syn_flood:candidate['correlation']['syn_load_alerts_enabled']=True
    if a.ssh_contact:
        if not any(s['kind']=='eve' for s in load_config(a.config)['sources']):
            parser.error('SSH contact observations require a Suricata EVE source')
        candidate['correlation']['ssh_contact_observations_enabled']=True
    if a.ssh_extended:candidate['correlation'].update(ssh_extended_chains_enabled=True,ssh_contact_observations_enabled=True,artifact_observation_enabled=True)
    if a.failure_threshold is not None:
        if not 2<=a.failure_threshold<=1000:parser.error('failure-threshold must be 2..1000')
        candidate['correlation']['failure_threshold']=a.failure_threshold
    # Validate before replacing; write_json itself uses an atomic replacement.
    import tempfile
    with tempfile.TemporaryDirectory() as folder:
        path=Path(folder)/'candidate.json';write_json(path,candidate);load_config(path)
    if candidate!=config:
        backup=a.config.with_name(a.config.name+'.before-chains-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
        shutil.copy2(a.config,backup);write_json(a.config,candidate);print('CONFIG_BACKUP:',backup)
    print('ATTACK_CHAIN_ENABLED; start a NEW Live session. Existing weights/SSH/PAM unchanged.')
    if a.ssh_contact:print('SSH_CONTACT_OBSERVATIONS_ENABLED: neutral candidate from SYN; no completed-flow wait; no Nmap/attack attribution.')
    if a.http_flood:print('HTTP_FLOOD_ALERTS_ENABLED: verify same-route baseline and Wazuh rules 119217/119218 before traffic.')


if __name__=='__main__':main()
